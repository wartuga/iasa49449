from exercicio_pdm.modelo_pdm_impl import ModeloPDMImpl
from pdm.pdm import PDM

s = [1,2,3,4,5,6,7]
A = [-1, 1]
T = lambda s, a, sn: 1 if s != 1 and s != 7 else 0
R = lambda s, a, sn: -1 if s == 2 and a == -1 and sn == 1 else 1 if s == 6 and a == 1 and sn == 7 else 0

# erro na utilidade do sn, não entendi o motivo

modelo = ModeloPDMImpl(s, {1: A, 2: A, 3: A, 4: A, 5: A, 6: A, 7: A}, T, R)
pdm = PDM(modelo, 0.5, 0)

print(pdm.resolver())