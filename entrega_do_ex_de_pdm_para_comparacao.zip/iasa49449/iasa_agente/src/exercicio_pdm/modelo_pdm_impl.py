from pdm.modelo.modelo_pdm import ModeloPDM

class ModeloPDMImpl(ModeloPDM):
    def __init__(self, S, A, T, R):
        self.__S = S
        self.__A = A
        self.__T = T
        self.__R = R

    def S(self):
        return self.__S
    
    def A(self, s):
        return self.__A[s]
    
    def T(self, s, a, sn):
        return self.__T(s, a, sn)
    
    def R(self, s, a, sn):
        return self.__R(s, a, sn)
    
    def suc(self, s, a):
        return (s + a[0], s + a[1])