from abc import ABC, abstractmethod

"""

"""
class Plano(ABC):

    @abstractmethod
    def obter_accao(self, estado):
        """
        Obtem o operador segundo o estado recebido
        """

    @abstractmethod
    def mostrar(self, vista):
        """
        Método para mostrar o plano com base na 
        vista recebida
        """