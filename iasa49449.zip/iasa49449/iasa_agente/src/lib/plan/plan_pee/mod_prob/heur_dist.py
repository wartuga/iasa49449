from pee.melhor_prim.aval.heuristica import Heuristica
from math import dist

"""
Representa uma heurística baseada em distância
"""
class HeurDist(Heuristica):
    """
    Construtor da classe
    """
    def __init__(self, estado_final):
        self.__estado_final = estado_final

    """
    Método para calcular a distância entre
    o estado atual e o estado objetivo
    """
    def h(self, estado):
        return abs(dist(estado.posicao, self.__estado_final.posicao))