from mod.problema import Problema

"""
Representa o problema do planeador com base no mecanismo
de procura melhor primeiro
"""
class ProblemaPlan(Problema):
    """
    Construtor da classe
    """
    def __init__(self, modelo_plan, estado_final):
        self.__estado_final = estado_final

    """
    Método para verificar se o estado recebido
    é o estado final
    """
    def objetivo(self, estado):
        return self.__estado_final == estado