from .transferir import Transferir

class Vazar(Transferir):
    """
    
    """
    def aplicar(self, estado):
        resultado = estado.volume - self.__volume
        if resultado < 0:
            return 0