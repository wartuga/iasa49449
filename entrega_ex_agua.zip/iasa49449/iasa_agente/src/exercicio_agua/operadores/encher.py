from .transferir import Transferir

class Encher(Transferir):
    """
    
    """
    def aplicar(self, estado):
        return estado.volume + self.__volume