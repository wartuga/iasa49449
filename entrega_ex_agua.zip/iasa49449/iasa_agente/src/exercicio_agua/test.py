from exercicio_agua.problema import Deposito
from pee.melhor_prim.procura_custo_unif import ProcuraCustoUnif

volume_inicial = 0
volume_final = 9
solucao = []

problema = Deposito(volume_inicial, volume_final)
custo_uniforme = ProcuraCustoUnif()
solucao = custo_uniforme.procurar(problema)

print(solucao)